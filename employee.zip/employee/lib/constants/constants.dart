class Constants {
  static const employeeTable = "employees";
  static const departmentTable = "departments";
  static const attendancetable = "attendance";
}
